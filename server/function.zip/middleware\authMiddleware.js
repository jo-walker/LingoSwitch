const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
  const token = req.header('Authorization')?.replace('Bearer ', ''); 
  if (!token) return res.status(401).json({ message: 'Access denied' });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET); 
    req.user = decoded;  

    // Log the decoded token to see what it contains
    console.log('Decoded token:', req.user);
    console.log('User ID:', req.user.id);
    console.log('Project ID:', req.body.projectId);
  
    next();
  } catch (err) {
    res.status(400).json({ message: 'Invalid token' });
  }
};